import { usersService, sessionsService, tournamentsService } from "@/lib/services";

export const initializeDemoData = () => {
  // Check if demo data already exists
  const existingUsers = usersService.getAll();
  if (existingUsers.length > 0) return;

  // Create demo coach
  const demoCoach = usersService.createUser({
    name: "Coach Alex",
    email: "coach@demo.com",
    phone: "+254 712 345 678",
    role: "coach",
    contactDetails: {
      whatsapp: "+254 712 345 678",
      telegram: "@coachalex",
      preferredChannel: "In-app chat",
      note: "Message me for training plans and tournament prep.",
    },
    specialty: "Advanced Techniques",
    rating: 4.8,
    reviews: 42,
    hourlyRate: 5000,
  } as any);

  // Create demo player
  const demoPlayer = usersService.createUser({
    name: "John Player",
    email: "player@demo.com",
    phone: "+254 701 234 567",
    role: "player",
  });

  const demoTrainee = usersService.createUser({
    name: "Tina Trainee",
    email: "trainee@demo.com",
    phone: "+254 700 222 111",
    role: "trainee",
  });

  // Create demo session
  sessionsService.createSession({
    coachId: demoCoach.id,
    playerId: demoPlayer.id,
    coachName: demoCoach.name,
    playerName: demoPlayer.name,
    date: "2026-03-15",
    time: "10:00 AM",
    type: "One-on-One",
    duration: 60,
    status: "Confirmed",
    amount: 5000,
    mediaUrls: [],
  });

  // Create demo tournament
  tournamentsService.createTournament({
    name: "Spring Championship",
    coachId: demoCoach.id,
    date: "2026-04-10",
    location: "Central Tennis Courts",
    prizePool: 1000000,
    participants: 64,
    category: "Open",
    entryFee: 5000,
    registeredPlayers: [demoPlayer.id, demoTrainee.id],
    description: "Annual spring tournament",
    rules: "Standard ITF rules apply",
    mediaUrls: [],
    status: "Active",
  } as any);
};
