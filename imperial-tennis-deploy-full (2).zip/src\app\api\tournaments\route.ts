import { NextResponse } from "next/server";
import { tournaments } from "@/lib/serverStore";
import { Tournament } from "@/lib/types";

export async function GET() {
  return NextResponse.json(tournaments);
}

export async function POST(req: Request) {
  const data = await req.json();
  const newTournament: Tournament = {
    ...data,
    id: `tournament_${Date.now()}`,
    registeredPlayers: data.registeredPlayers || [],
    status: data.status || "Active",
  };
  tournaments.push(newTournament);
  return NextResponse.json(newTournament);
}
