import { NextResponse } from "next/server";
import { users } from "@/lib/serverStore";
import { User } from "@/lib/types";

export async function GET() {
  return NextResponse.json(users);
}

export async function POST(req: Request) {
  const data = await req.json();
  const newUser: User = {
    ...data,
    id: `user_${Date.now()}`,
    createdAt: new Date().toISOString(),
  };
  users.push(newUser);
  return NextResponse.json(newUser);
}
