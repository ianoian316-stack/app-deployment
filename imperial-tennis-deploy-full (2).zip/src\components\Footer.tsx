import Link from "next/link";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-slate-200">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold text-emerald-400">IMPERIAL TENNIS</h3>
            <p className="text-slate-400 mt-2">
              Players, trainees, and coaches connected in one payment-ready tennis platform.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Platform</h4>
            <div className="space-y-2 text-slate-400">
              <Link href="/players/book-session" className="block hover:text-emerald-300">
                Coaching Sessions
              </Link>
              <Link href="/players/tournaments" className="block hover:text-emerald-300">
                Tournaments
              </Link>
              <Link href="/coaches/create-tournament" className="block hover:text-emerald-300">
                Coach Tools
              </Link>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Legal</h4>
            <div className="space-y-2 text-slate-400">
              <Link href="/privacy" className="block hover:text-emerald-300">
                Privacy Policy
              </Link>
              <Link href="/terms" className="block hover:text-emerald-300">
                Terms
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-slate-800 pt-5 text-sm text-slate-500">
          © {currentYear} IMPERIAL TENNIS
        </div>
      </div>
    </footer>
  );
}
