export default function FeaturesPage() {
  const features = [
    {
      icon: "📅",
      title: "Smart Session Booking",
      description:
        "Easily schedule and manage coaching sessions with real-time availability.",
    },
    {
      icon: "💳",
      title: "Secure Payments",
      description:
        "Process payments safely with Stripe integration and instant payouts.",
    },
    {
      icon: "🏆",
      title: "Tournament Management",
      description:
        "Create, manage, and participate in tennis tournaments all in one place.",
    },
    {
      icon: "📊",
      title: "Progress Tracking",
      description:
        "Monitor improvement with detailed statistics and performance analytics.",
    },
    {
      icon: "👥",
      title: "Coach Profiles",
      description:
        "Browse coaches with ratings, reviews, and verified credentials.",
    },
    {
      icon: "🔔",
      title: "Smart Notifications",
      description:
        "Get reminders and updates about bookings and tournament schedules.",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">Powerful Features</h1>
          <p className="text-xl opacity-90">
            Everything you need to excel in tennis
          </p>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="card text-center hover:shadow-xl transition">
              <div className="text-6xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed Features Section */}
      <section className="bg-white py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="section-title">Why IMPERIAL TENNIS?</h2>

          <div className="space-y-12">
            {/* Feature 1 */}
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold mb-4 text-gray-900">
                  Coaches Get More Students
                </h3>
                <p className="text-gray-600 mb-4">
                  Our platform connects you with dedicated players looking for
                  quality coaching. Build your student base and grow your
                  business.
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>✓ Professional profile showcase</li>
                  <li>✓ Student management tools</li>
                  <li>✓ Flexible scheduling</li>
                </ul>
              </div>
              <div className="bg-primary-100 rounded-lg p-8 text-center">
                <div className="text-6xl mb-4">👨‍🏫</div>
                <p className="font-semibold text-gray-600">Coach Benefits</p>
              </div>
            </div>

            {/* Feature 2 */}
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="bg-accent-100 rounded-lg p-8 text-center">
                <div className="text-6xl mb-4">🎾</div>
                <p className="font-semibold text-gray-600">Player Benefits</p>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-4 text-gray-900">
                  Players Achieve Their Goals
                </h3>
                <p className="text-gray-600 mb-4">
                  Access top-rated coaches, competitive tournaments, and
                  comprehensive progress tracking all in one platform. All data
                  is backed by a server-side API, making future mobile or
                  desktop clients easy to build.
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>✓ Find the perfect coach</li>
                  <li>✓ Book sessions instantly</li>
                  <li>✓ Compete in tournaments</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-primary text-white py-12 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/auth/register" className="btn-secondary">
              Sign Up Now
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
