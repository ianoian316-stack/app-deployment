# IMPERIAL TENNIS - Copilot Instructions

## Project Overview

IMPERIAL TENNIS is a comprehensive web platform connecting tennis coaches and players. The platform enables coaches to receive payments for tournaments and coaching lessons, while trainees/players can pay coaching fees, book coaching sessions, and book tournaments.

## Technology Stack

- **Framework**: Next.js 15 with TypeScript
- **Styling**: Tailwind CSS
- **UI Colors**: Primary Green (#22c55e) and Blue (#0ea5e9)
- **Components**: React 19 with custom components

## Project Structure

```
src/
├── app/
│   ├── auth/              # Authentication pages
│   ├── players/           # Player features
│   ├── coaches/           # Coach features
│   ├── page.tsx          # Home page
│   └── layout.tsx        # Root layout
├── components/            # Reusable React components
├── lib/                  # Utility functions
└── app/(other pages)/    # Static pages
```

## Key Features Implemented

### Home Page
- Hero section with CTA buttons
- Feature highlights (4 columns)
- Sections for players and coaches
- Call-to-action section

### Authentication
- Registration page with role selection
- Login page with social login options
- Form validation with error handling

### Player Features
- Dashboard with stats and quick actions
- Book coaching sessions with coach filters
- Browse and register for tournaments
- Session and tournament tracking

### Coach Features
- Dashboard with earnings overview
- Create and manage tournaments
- View earnings and payments
- Track active students

### Static Pages
- Features page
- About page
- Privacy policy
- Terms of service

## Styling Guidelines

### Color Palette
- **Primary**: #0ea5e9 (Sky Blue)
- **Accent**: #22c55e (Green)
- **Text**: Gray-900 for headings, Gray-600 for body
- **Backgrounds**: White cards on Gray-50 background

### Tailwind Classes
- Use `btn-primary` for primary actions
- Use `btn-secondary` for secondary actions
- Use `card` for content containers
- Use `gradient-primary` for hero sections

## Future Development

### Phase 1: Backend API
- Set up Express.js API routes or connect to backend
- Implement database (PostgreSQL/MongoDB)
- Set up authentication system

### Phase 2: Payment Integration
- Integrate Stripe for payments
- Set up payment processing
- Implement withdrawal system for coaches

### Phase 3: Features
- Real-time notifications
- Video call integration
- Email notifications
- SMS reminders
- Rating and review system

### Phase 4: Analytics
- Performance tracking
- Usage analytics
- Earnings reports

## Development Guidelines

1. **Component Creation**:
   - Keep components modular and reusable
   - Use TypeScript for type safety
   - Add proper prop validation

2. **Styling**:
   - Use Tailwind CSS utilities
   - Maintain consistent spacing and sizing
   - Follow the color scheme

3. **Routing**:
   - Use Next.js App Router
   - Keep routes organized by user type
   - Use proper page titles and metadata

4. **Forms**:
   - Use React Hook Form with Zod validation
   - Provide clear error messages
   - Show loading states

5. **Testing**:
   - Test across different screen sizes
   - Verify form validation
   - Check all links and navigation

## Environment Variables

For future setup, add to `.env.local`:
```
NEXT_PUBLIC_API_URL=http://localhost:3000
DATABASE_URL=your_database_url
STRIPE_PUBLIC_KEY=your_stripe_public_key
STRIPE_SECRET_KEY=your_stripe_secret_key
```

## Running the Project

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Notes

- All pages are fully responsive
- Color scheme uses green and blue as requested
- Splash of accent colors added for visual appeal
- Platform ready for payment integration
- Database structure can be added when backend is configured
