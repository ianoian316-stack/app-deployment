export interface ContactDetails {
  whatsapp?: string;
  telegram?: string;
  instagram?: string;
  preferredChannel?: "Phone" | "WhatsApp" | "Email" | "In-app chat";
  note?: string;
}

// User types
export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: "coach" | "player" | "trainee";
  contactDetails?: ContactDetails;
  specialty?: string;
  rating?: number;
  reviews?: number;
  hourlyRate?: number;
  availability?: string;
  students?: string[];
  earnings?: number;
  level?: string;
  bookedSessions?: string[];
  registeredTournaments?: string[];
  createdAt: string;
}

export interface Coach extends User {
  role: "coach";
  specialty: string;
  rating: number;
  reviews: number;
  hourlyRate: number;
  availability: string;
  students: string[];
  earnings: number;
}

export interface Player extends User {
  role: "player" | "trainee";
  level: string;
  bookedSessions: string[];
  registeredTournaments: string[];
}

// Session types
export interface CoachingSession {
  id: string;
  coachId: string;
  playerId: string;
  coachName: string;
  playerName: string;
  date: string;
  time: string;
  type: string;
  duration: number;
  status: "Confirmed" | "Pending" | "Cancelled";
  amount: number;
  // optional media URLs (images or videos) added by coach
  mediaUrls?: string[];
}

// Tournament types
export interface Tournament {
  id: string;
  name: string;
  coachId: string;
  date: string;
  location: string;
  prizePool: number;
  participants: number;
  category: string;
  entryFee: number;
  description: string;
  rules: string;
  registeredPlayers: string[];
  status: "Active" | "Closed" | "Completed";
  // coach can upload photos/videos for promotion
  mediaUrls?: string[];
}

// Payment types
export interface Payment {
  id: string;
  userId: string;
  amount: number;
  type: "coaching_fee" | "tournament_entry" | "withdrawal";
  status: "Pending" | "Completed" | "Failed";
  date: string;
  description: string;
}

export interface ChatConversation {
  id: string;
  participants: string[];
  sharedKey: string;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  encryptedContent: string;
  iv: string;
  readBy: string[];
  createdAt: string;
}

export type RegisterUserInput = Omit<User, "id" | "createdAt"> &
  Partial<
    Pick<
      Coach,
      | "specialty"
      | "rating"
      | "reviews"
      | "hourlyRate"
      | "availability"
      | "students"
      | "earnings"
    >
  > &
  Partial<Pick<Player, "level" | "bookedSessions" | "registeredTournaments">>;
