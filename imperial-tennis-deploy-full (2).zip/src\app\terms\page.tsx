export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold">Terms of Service</h1>
          <p className="text-lg opacity-90 mt-2">
            Last updated: February 25, 2026
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="bg-white rounded-lg shadow p-8 space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              1. Agreement To Terms
            </h2>
            <p className="text-gray-600">
              By accessing and using the IMPERIAL TENNIS website and
              application, you accept and agree to be bound by the terms and
              provision of this agreement.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              2. Use License
            </h2>
            <p className="text-gray-600 mb-4">
              Permission is granted to temporarily download one copy of the
              materials (information or software) on IMPERIAL TENNIS for
              personal, non-commercial transitory viewing only. This is the
              grant of a license, not a transfer of title, and under this
              license you may not:
            </p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex gap-3">
                <span>•</span>
                <span>Modifying or copying the materials</span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>Using the materials for any commercial purpose</span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>
                  Attempting to decompile or reverse engineer any software
                </span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>Removing any copyright or other proprietary notations</span>
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              3. Disclaimer
            </h2>
            <p className="text-gray-600">
              The materials on IMPERIAL TENNIS are provided on an &apos;as is&apos; basis.
              IMPERIAL TENNIS makes no warranties, expressed or implied, and
              hereby disclaims and negates all other warranties including,
              without limitation, implied warranties or conditions of
              merchantability, fitness for a particular purpose, or
              non-infringement of intellectual property or other violation of
              rights.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              4. Limitations
            </h2>
            <p className="text-gray-600">
              In no event shall IMPERIAL TENNIS or its suppliers be liable for
              any damages (including, without limitation, damages for loss of
              data or profit, or due to business interruption) arising out of
              the use or inability to use the materials on IMPERIAL TENNIS.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              5. Accuracy Of Materials
            </h2>
            <p className="text-gray-600">
              The materials appearing on IMPERIAL TENNIS could include
              technical, typographical, or photographic errors. IMPERIAL TENNIS
              does not warrant that any of the materials on our website are
              accurate, complete, or current.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              6. Links
            </h2>
            <p className="text-gray-600">
              IMPERIAL TENNIS has not reviewed all of the sites linked to our
              website and is not responsible for the contents of any such linked
              site. The inclusion of any link does not imply endorsement by
              IMPERIAL TENNIS of the site. Use of any such linked website is at
              the user&apos;s own risk.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              7. Modifications
            </h2>
            <p className="text-gray-600">
              IMPERIAL TENNIS may revise these terms of service for our website
              at any time without notice. By using this website, you are
              agreeing to be bound by the then current version of these terms of
              service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              8. Governing Law
            </h2>
            <p className="text-gray-600">
              These terms and conditions are governed by and construed in
              accordance with the laws of [Your Jurisdiction] and you
              irrevocably submit to the exclusive jurisdiction of the courts
              located in that location.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact</h2>
            <p className="text-gray-600">
              If you have any questions about these Terms of Service, please
              contact us at: terms@imperialtennis.com
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
