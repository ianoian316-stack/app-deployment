# IMPERIAL TENNIS 🎾

A comprehensive web platform connecting tennis coaches and players for seamless interaction, booking, and payment management.

## Overview

IMPERIAL TENNIS is a modern web application designed to revolutionize how coaches and players interact in the tennis community. The platform enables:

- **For Coaches**:
  - Manage coaching profiles and availability
  - Create and manage tournaments
  - Track earnings and payments
  - Build a student base
  - Set coaching rates and session types

- **For Players**:
  - Book coaching sessions with top coaches
  - Register for tournaments
  - Pay coaching fees securely
  - Track progress and statistics
  - Find coaches based on specialties and rates

## Tech Stack

- **Frontend**: Next.js 15 with TypeScript and React 19
- **Styling**: Tailwind CSS with custom green and blue theme
- **Authentication**: Email/password and social login ready
- **Forms**: React Hook Form with Zod validation
- **UI Components**: Custom components with Lucide React icons
- **Database Ready**: Prepared for PostgreSQL/MongoDB integration
- **Payment Ready**: Structure ready for Stripe integration

## Features

### Core Features
- ✅ User Authentication (Coaches and Players)
- ✅ Coach Profile Management
- ✅ Coaching Session Booking System
- ✅ Tournament Management
- ✅ Payment Processing Interface
- ✅ Earnings Dashboard
- ✅ User-friendly Navigation
- ✅ Responsive Design (Mobile & Desktop)

### Design
-🎨 Green and Blue color scheme
- 🌈 Modern, attractive UI with gradients
- 📱 Fully responsive layout
- ♿ Accessible components
- ⚡ Smooth animations and transitions

## Project Structure

```
imperial-tennis/
├── src/
│   ├── app/
│   │   ├── auth/
│   │   │   ├── login/page.tsx
│   │   │   └── register/page.tsx
│   │   ├── players/
│   │   │   ├── dashboard/page.tsx
│   │   │   ├── book-session/page.tsx
│   │   │   └── tournaments/page.tsx
│   │   ├── coaches/
│   │   │   ├── dashboard/page.tsx
│   │   │   ├── create-tournament/page.tsx
│   │   │   └── earnings/page.tsx
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── globals.css
│   │   └── [other pages]
│   ├── components/
│   │   ├── Navbar.tsx
│   │   ├── Footer.tsx
│   │   └── [other components]
│   └── lib/
│       └── [utility functions]
├── public/
├── tailwind.config.ts
├── tsconfig.json
├── package.json
└── next.config.js
```

## Installation

This version now includes a rudimentary server-side API using Next.js route handlers. The frontend currently uses localStorage for data, but the following endpoints are available for future integration:

- `GET /api/users` & `POST /api/users`
- `GET /api/sessions` & `POST /api/sessions`
- `GET /api/tournaments` & `POST /api/tournaments`
- `GET /api/payments` & `POST /api/payments`
- `POST /api/checkout` – creates a Stripe PaymentIntent (requires `STRIPE_SECRET_KEY`)

During development these routes store records in memory (see `src/lib/serverStore.ts`).

### Environment Variables

Create a `.env.local` file in the root directory:
```
NEXT_PUBLIC_API_URL=http://localhost:3000
DATABASE_URL=your_database_url
STRIPE_PUBLIC_KEY=your_stripe_public_key
STRIPE_SECRET_KEY=your_stripe_secret_key
```

(you can ignore `DATABASE_URL` until a real database is connected)

## Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/imperialtennis/imperial-tennis.git
   cd imperial-tennis
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   Create a `.env.local` file in the root directory:
   ```
   NEXT_PUBLIC_API_URL=http://localhost:3000
   DATABASE_URL=your_database_url
   STRIPE_PUBLIC_KEY=your_stripe_public_key
   STRIPE_SECRET_KEY=your_stripe_secret_key
   ```

4. **Run development server**:
   ```bash
   npm run dev
   ```

5. **Open browser**:
   Navigate to `http://localhost:3000`

## Available Routes

### Authentication
- `/auth/login` - User login page
- `/auth/register` - User registration page

### Player Routes
- `/players/dashboard` - Player dashboard
- `/players/book-session` - Book coaching sessions
- `/players/tournaments` - Browse and register tournaments

### Coach Routes
- `/coaches/dashboard` - Coach dashboard
- `/coaches/create-tournament` - Create new tournaments
- `/coaches/earnings` - View earnings and payments

### Static Pages
- `/` - Home page
- `/features` - Features page
- `/about` - About page
- `/privacy` - Privacy policy
- `/terms` - Terms of service

## Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run lint` - Run ESLint

## Future Enhancements

- [ ] Payment integration (Stripe)
- [ ] Email notifications
- [ ] SMS reminders
- [ ] Video tutorials
- [ ] Performance analytics
- [ ] Real-time chat
- [ ] Mobile app (React Native)
- [ ] Video call integration
- [ ] Player ratings and reviews
- [ ] Certificate generation

## Color Scheme

- **Primary Blue**: `#0ea5e9` (Sky blue)
- **Accent Green**: `#22c55e` (Emerald green)
- **Secondary**: Various shades for UI elements
- **Neutral**: Gray for text and backgrounds

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Security

- Secure password handling
- Input validation and sanitization
- HTTPS ready
- CORS configured
- XSS protection included

## Performance

- Optimized images with Next.js Image component
- Code splitting and lazy loading
- CSS optimization with Tailwind
- Fast page load times

## Contributing

We welcome contributions! Please follow our coding standards and submit pull requests with detailed descriptions.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@imperialtennis.com or visit our website.

## Roadmap

- Q1 2026: Core platform launch
- Q2 2026: Payment integration
- Q3 2026: Mobile app launch
- Q4 2026: Advanced analytics

---

Built with ❤️ for the tennis community
