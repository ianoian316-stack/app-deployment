import { ChatConversation, ChatMessage } from "@/lib/types";
import {
  decryptChatMessage,
  encryptChatMessage,
  generateConversationKey,
} from "@/lib/chatCrypto";

const STORAGE_KEYS = {
  CONVERSATIONS: "imperial_chat_conversations",
  MESSAGES: "imperial_chat_messages",
};

const getConversations = (): ChatConversation[] => {
  if (typeof window === "undefined") return [];
  const raw = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
  return raw ? (JSON.parse(raw) as ChatConversation[]) : [];
};

const setConversations = (conversations: ChatConversation[]) => {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(conversations));
};

const getMessages = (): ChatMessage[] => {
  if (typeof window === "undefined") return [];
  const raw = localStorage.getItem(STORAGE_KEYS.MESSAGES);
  if (!raw) return [];
  const parsed = JSON.parse(raw) as Array<ChatMessage & { readBy?: string[] }>;
  return parsed.map((message) => ({
    ...message,
    readBy: message.readBy || [message.senderId],
  }));
};

const setMessages = (messages: ChatMessage[]) => {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
};

const sortByUpdatedAt = (items: ChatConversation[]) =>
  [...items].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );

export const messagesService = {
  getUserConversations: (userId: string) =>
    sortByUpdatedAt(getConversations().filter((c) => c.participants.includes(userId))),

  getConversationById: (conversationId: string) =>
    getConversations().find((c) => c.id === conversationId) || null,

  getOrCreateDirectConversation: async (userA: string, userB: string) => {
    const existing = getConversations().find(
      (conversation) =>
        conversation.participants.length === 2 &&
        conversation.participants.includes(userA) &&
        conversation.participants.includes(userB)
    );
    if (existing) return existing;

    const now = new Date().toISOString();
    const conversation: ChatConversation = {
      id: `conversation_${Date.now()}`,
      participants: [userA, userB],
      sharedKey: await generateConversationKey(),
      createdAt: now,
      updatedAt: now,
    };

    const conversations = getConversations();
    conversations.push(conversation);
    setConversations(conversations);
    return conversation;
  },

  sendMessage: async (
    conversationId: string,
    senderId: string,
    plainText: string
  ) => {
    const conversation = getConversations().find((c) => c.id === conversationId);
    if (!conversation) {
      throw new Error("Conversation not found");
    }

    const encrypted = await encryptChatMessage(plainText, conversation.sharedKey);
    const message: ChatMessage = {
      id: `message_${Date.now()}_${Math.floor(Math.random() * 10000)}`,
      conversationId,
      senderId,
      encryptedContent: encrypted.encryptedContent,
      iv: encrypted.iv,
      readBy: [senderId],
      createdAt: new Date().toISOString(),
    };

    const messages = getMessages();
    messages.push(message);
    setMessages(messages);

    const conversations = getConversations().map((item) =>
      item.id === conversationId
        ? { ...item, updatedAt: new Date().toISOString() }
        : item
    );
    setConversations(conversations);

    return message;
  },

  markConversationAsRead: (conversationId: string, userId: string) => {
    const messages = getMessages();
    const updated = messages.map((message) => {
      if (message.conversationId !== conversationId) return message;
      if (message.readBy.includes(userId)) return message;
      return { ...message, readBy: [...message.readBy, userId] };
    });
    setMessages(updated);
  },

  getUnreadCount: (userId: string) => {
    const userConversationIds = new Set(
      getConversations()
        .filter((conversation) => conversation.participants.includes(userId))
        .map((conversation) => conversation.id)
    );

    return getMessages().filter(
      (message) =>
        userConversationIds.has(message.conversationId) &&
        message.senderId !== userId &&
        !message.readBy.includes(userId)
    ).length;
  },

  getDecryptedMessages: async (conversationId: string) => {
    const conversation = getConversations().find((c) => c.id === conversationId);
    if (!conversation) return [];

    const messages = getMessages().filter((m) => m.conversationId === conversationId);
    const decrypted = await Promise.all(
      messages.map(async (message) => ({
        ...message,
        content: await decryptChatMessage(
          message.encryptedContent,
          message.iv,
          conversation.sharedKey
        ),
      }))
    );

    return decrypted.sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
  },
};
