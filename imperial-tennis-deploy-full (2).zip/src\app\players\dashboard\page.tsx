"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { sessionsService, tournamentsService } from "@/lib/services";
import { CoachingSession, Tournament } from "@/lib/types";
import { initializeDemoData } from "@/lib/demoData";

export default function PlayerDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [upcomingSessions, setUpcomingSessions] = useState<CoachingSession[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    // Initialize demo data on first load
    initializeDemoData();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        router.push("/auth/login");
      }
    }
  }, [isLoading, isAuthenticated, router]);

  useEffect(() => {
    if (user) {
      if (user.role === "player" || user.role === "trainee") {
        const sessions = sessionsService.getByPlayerId(user.id);
        setUpcomingSessions(sessions);

        const allTournaments = tournamentsService.getAll();
        const registeredTournaments = allTournaments.filter((t) =>
          t.registeredPlayers.includes(user.id)
        );
        setTournaments(registeredTournaments);
      }
      setDataLoading(false);
    }
  }, [user]);

  if (isLoading || dataLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (
    !isAuthenticated ||
    !user ||
    (user.role !== "player" && user.role !== "trainee")
  ) {
    return null;
  }

  const handleCancelSession = (sessionId: string) => {
    sessionsService.deleteSession(sessionId);
    setUpcomingSessions(upcomingSessions.filter((s) => s.id !== sessionId));
  };

  const handleUnregisterTournament = (tournamentId: string) => {
    tournamentsService.unregisterPlayer(tournamentId, user.id);
    setTournaments(tournaments.filter((t) => t.id !== tournamentId));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-8 px-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Welcome, {user.name}!</h1>
          <p className="text-lg opacity-90">Manage your sessions and tournaments</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {/* Stats Cards */}
          <div className="card bg-gradient-to-br from-primary-50 to-primary-100">
            <div className="text-4xl font-bold text-primary-600 mb-2">
              {upcomingSessions.length}
            </div>
            <p className="text-gray-600">Upcoming Sessions</p>
          </div>

          <div className="card bg-gradient-to-br from-accent-50 to-accent-100">
            <div className="text-4xl font-bold text-accent-600 mb-2">
              {tournaments.length}
            </div>
            <p className="text-gray-600">Registered Tournaments</p>
          </div>

          <div className="card bg-gradient-to-br from-orange-50 to-orange-100">
            <div className="text-4xl font-bold text-orange-600 mb-2">KES 0</div>
            <p className="text-gray-600">Account Balance</p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Link href="/players/book-session" className="card text-center hover:shadow-lg transition">
            <div className="text-4xl mb-4">📅</div>
            <h3 className="text-xl font-bold mb-2">Book a Session</h3>
            <p className="text-gray-600">Schedule one-on-one coaching</p>
          </Link>

          <Link href="/players/tournaments" className="card text-center hover:shadow-lg transition">
            <div className="text-4xl mb-4">🏆</div>
            <h3 className="text-xl font-bold mb-2">Register Tournament</h3>
            <p className="text-gray-600">Join upcoming tournaments</p>
          </Link>

          <Link href="/players/book-session" className="card text-center hover:shadow-lg transition">
            <div className="text-4xl mb-4">👥</div>
            <h3 className="text-xl font-bold mb-2">Find Coaches</h3>
            <p className="text-gray-600">Browse available coaches</p>
          </Link>
        </div>

        {/* Upcoming Sessions */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-gray-900">
            Upcoming Sessions
          </h2>
          {upcomingSessions.length === 0 ? (
            <div className="card text-center py-8">
              <p className="text-gray-600 mb-4">No upcoming sessions</p>
              <Link href="/players/book-session" className="btn-primary inline-block">
                Book Your First Session
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingSessions.map((session) => (
                <div key={session.id} className="card flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">
                      {session.coachName}
                    </h3>
                    <p className="text-gray-600">
                      {session.date} at {session.time}
                    </p>
                    <p className="text-sm text-primary-600 font-semibold">
                      {session.type}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="px-4 py-2 bg-accent-100 text-accent-700 rounded-lg font-semibold">
                      {session.status}
                    </span>
                    <button
                      onClick={() => handleCancelSession(session.id)}
                      className="px-4 py-2 text-red-600 border-2 border-red-600 rounded-lg hover:bg-red-50 font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Registered Tournaments */}
        <section>
          <h2 className="text-2xl font-bold mb-6 text-gray-900">
            Registered Tournaments
          </h2>
          {tournaments.length === 0 ? (
            <div className="card text-center py-8">
              <p className="text-gray-600 mb-4">Not registered in any tournaments</p>
              <Link href="/players/tournaments" className="btn-primary inline-block">
                Find Tournaments
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {tournaments.map((tournament) => (
                <div key={tournament.id} className="card">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">
                        {tournament.name}
                      </h3>
                      <p className="text-gray-600">{tournament.date}</p>
                      <p className="text-gray-600">{tournament.location}</p>
                    </div>
                    <span className="px-4 py-2 bg-accent-100 text-accent-700 rounded-lg font-semibold">
                      Registered
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-xl font-bold text-gray-900">
                      {tournament.entryFee}
                    </p>
                    <button
                      onClick={() => handleUnregisterTournament(tournament.id)}
                      className="px-4 py-2 text-red-600 border-2 border-red-600 rounded-lg hover:bg-red-50 font-semibold"
                    >
                      Unregister
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
