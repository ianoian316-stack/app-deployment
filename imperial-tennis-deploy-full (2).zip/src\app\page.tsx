import Link from "next/link";

const features = [
  {
    title: "Players",
    text: "Register and pay for upcoming tournaments from one dashboard.",
  },
  {
    title: "Trainees",
    text: "Book coaching sessions and also join tournaments with secure checkout.",
  },
  {
    title: "Coaches",
    text: "Create tournaments, publish them to the community, and receive payments.",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#dbeafe_0%,#dcfce7_45%,#f8fafc_100%)]">
      <section className="px-6 py-20">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="inline-flex px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-sm font-semibold">
              IMPERIAL TENNIS
            </p>
            <h1 className="mt-5 text-5xl md:text-6xl font-black tracking-tight text-sky-900 leading-tight">
              Tennis community + tournament payments in one app.
            </h1>
            <p className="mt-6 text-lg text-slate-700 max-w-xl">
              Built for players, trainees, and coaches to interact, train, compete, and pay.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/auth/register"
                className="px-6 py-3 rounded-lg text-white font-semibold bg-gradient-to-r from-sky-600 to-emerald-600 hover:from-sky-700 hover:to-emerald-700"
              >
                Create Account
              </Link>
              <Link
                href="/auth/login"
                className="px-6 py-3 rounded-lg border border-sky-600 text-sky-700 font-semibold hover:bg-sky-50"
              >
                Sign In
              </Link>
            </div>
          </div>

          <div className="rounded-3xl p-8 bg-gradient-to-br from-sky-700 to-emerald-600 text-white shadow-2xl">
            <h2 className="text-2xl font-bold">What You Can Do</h2>
            <ul className="mt-5 space-y-3 text-sky-50">
              <li>Pay entry fees for upcoming tournaments</li>
              <li>Book and pay for coaching sessions</li>
              <li>Create and publish tournaments as a coach</li>
              <li>Track earnings and completed payments</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="px-6 pb-20">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6">
          {features.map((feature) => (
            <article
              key={feature.title}
              className="bg-white rounded-2xl border border-sky-100 shadow-md p-6"
            >
              <h3 className="text-2xl font-bold text-sky-900">{feature.title}</h3>
              <p className="mt-3 text-slate-700">{feature.text}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
