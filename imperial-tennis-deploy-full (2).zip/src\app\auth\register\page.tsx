"use client";

import Link from "next/link";
import { useState } from "react";
import Image from "next/image";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import { User } from "@/lib/types";

type RegisterRole = User["role"];

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "player" as RegisterRole,
    phone: "",
    specialty: "",
    hourlyRate: "",
    availability: "",
    agreeToTerms: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const { register } = useAuth();
  const router = useRouter();

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }));

    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const validateForm = () => {
    const nextErrors: Record<string, string> = {};

    if (!formData.name.trim()) nextErrors.name = "Name is required";
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      nextErrors.email = "Valid email is required";
    }
    if (formData.password.length < 8) {
      nextErrors.password = "Password must be at least 8 characters";
    }
    if (formData.password !== formData.confirmPassword) {
      nextErrors.confirmPassword = "Passwords do not match";
    }
    if (!formData.agreeToTerms) {
      nextErrors.agreeToTerms = "You must agree to terms";
    }
    if (formData.role === "coach") {
      if (!formData.specialty.trim()) {
        nextErrors.specialty = "Specialty is required for coaches";
      }
      if (!formData.hourlyRate || Number(formData.hourlyRate) <= 0) {
        nextErrors.hourlyRate = "Hourly rate must be greater than 0";
      }
      if (!formData.availability.trim()) {
        nextErrors.availability = "Availability is required";
      }
    }

    return nextErrors;
  };

  const getDashboardRoute = (role: RegisterRole) =>
    role === "coach" ? "/coaches/dashboard" : "/players/dashboard";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors = validateForm();

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    setIsLoading(true);
    const success = register({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      role: formData.role,
      specialty: formData.role === "coach" ? formData.specialty : undefined,
      hourlyRate:
        formData.role === "coach" ? Number(formData.hourlyRate) : undefined,
      availability: formData.role === "coach" ? formData.availability : undefined,
    });
    setIsLoading(false);

    if (!success) {
      setErrors({ email: "Registration failed. Email may already exist." });
      return;
    }

    router.push(getDashboardRoute(formData.role));
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#dbeafe_0%,#dcfce7_45%,#f8fafc_100%)] py-12 px-6">
      <div className="max-w-lg mx-auto bg-white/95 backdrop-blur rounded-2xl shadow-xl border border-sky-100 p-8">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-3">
            <Image src="/icon.svg" alt="Imperial Tennis" width={48} height={48} />
          </div>
          <h1 className="text-4xl font-black tracking-tight text-sky-800 mb-2">
            IMPERIAL TENNIS
          </h1>
          <p className="text-slate-600">
            Join as a player, trainee, or coach.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Full Name"
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
              errors.name ? "border-red-500" : "border-slate-300"
            }`}
          />
          {errors.name && <p className="text-sm text-red-600">{errors.name}</p>}

          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email Address"
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
              errors.email ? "border-red-500" : "border-slate-300"
            }`}
          />
          {errors.email && <p className="text-sm text-red-600">{errors.email}</p>}

          <input
            type="tel"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            placeholder="Phone Number"
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
          />

          <select
            name="role"
            value={formData.role}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
          >
            <option value="player">Player</option>
            <option value="trainee">Trainee</option>
            <option value="coach">Coach</option>
          </select>

          {formData.role === "coach" && (
            <>
              <input
                type="text"
                name="specialty"
                value={formData.specialty}
                onChange={handleChange}
                placeholder="Coaching Specialty"
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
                  errors.specialty ? "border-red-500" : "border-slate-300"
                }`}
              />
              {errors.specialty && (
                <p className="text-sm text-red-600">{errors.specialty}</p>
              )}

              <input
                type="number"
                name="hourlyRate"
                value={formData.hourlyRate}
                onChange={handleChange}
                placeholder="Hourly Rate (KES)"
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
                  errors.hourlyRate ? "border-red-500" : "border-slate-300"
                }`}
              />
              {errors.hourlyRate && (
                <p className="text-sm text-red-600">{errors.hourlyRate}</p>
              )}

              <input
                type="text"
                name="availability"
                value={formData.availability}
                onChange={handleChange}
                placeholder="Availability (e.g. Mon-Fri, 8 AM - 5 PM)"
                className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
                  errors.availability ? "border-red-500" : "border-slate-300"
                }`}
              />
              {errors.availability && (
                <p className="text-sm text-red-600">{errors.availability}</p>
              )}
            </>
          )}

          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password"
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
              errors.password ? "border-red-500" : "border-slate-300"
            }`}
          />
          {errors.password && (
            <p className="text-sm text-red-600">{errors.password}</p>
          )}

          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            placeholder="Confirm Password"
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
              errors.confirmPassword ? "border-red-500" : "border-slate-300"
            }`}
          />
          {errors.confirmPassword && (
            <p className="text-sm text-red-600">{errors.confirmPassword}</p>
          )}

          <label className="flex items-start gap-2 text-sm text-slate-600">
            <input
              type="checkbox"
              name="agreeToTerms"
              checked={formData.agreeToTerms}
              onChange={handleChange}
              className="mt-1"
            />
            <span>
              I agree to the{" "}
              <Link href="/terms" className="text-sky-700 hover:underline">
                Terms
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="text-sky-700 hover:underline">
                Privacy Policy
              </Link>
              .
            </span>
          </label>
          {errors.agreeToTerms && (
            <p className="text-sm text-red-600">{errors.agreeToTerms}</p>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-lg font-semibold text-white bg-gradient-to-r from-sky-600 to-emerald-600 hover:from-sky-700 hover:to-emerald-700 disabled:opacity-60"
          >
            {isLoading ? "Creating account..." : "Create Account"}
          </button>
        </form>

        <p className="text-center text-slate-600 mt-6">
          Already have an account?{" "}
          <Link href="/auth/login" className="text-sky-700 font-semibold hover:underline">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
}
