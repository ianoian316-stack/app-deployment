const encoder = new TextEncoder();
const decoder = new TextDecoder();

const toBase64 = (bytes: Uint8Array) => {
  let binary = "";
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return btoa(binary);
};

const fromBase64 = (base64: string) => {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
};

const importConversationKey = async (sharedKey: string) =>
  crypto.subtle.importKey(
    "raw",
    fromBase64(sharedKey),
    { name: "AES-GCM" },
    false,
    ["encrypt", "decrypt"]
  );

export const generateConversationKey = async () => {
  const key = await crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    true,
    ["encrypt", "decrypt"]
  );
  const exported = await crypto.subtle.exportKey("raw", key);
  return toBase64(new Uint8Array(exported));
};

export const encryptChatMessage = async (plainText: string, sharedKey: string) => {
  const key = await importConversationKey(sharedKey);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    encoder.encode(plainText)
  );

  return {
    encryptedContent: toBase64(new Uint8Array(encrypted)),
    iv: toBase64(iv),
  };
};

export const decryptChatMessage = async (
  encryptedContent: string,
  iv: string,
  sharedKey: string
) => {
  try {
    const key = await importConversationKey(sharedKey);
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: fromBase64(iv) },
      key,
      fromBase64(encryptedContent)
    );
    return decoder.decode(decrypted);
  } catch (_error) {
    return "[Unable to decrypt message]";
  }
};
