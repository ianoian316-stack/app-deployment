import {
  User,
  Coach,
  Player,
  CoachingSession,
  Tournament,
  Payment,
  RegisterUserInput,
} from "./types";

const STORAGE_KEYS = {
  USERS: "imperial_users",
  SESSIONS: "imperial_sessions",
  TOURNAMENTS: "imperial_tournaments",
  CURRENT_USER: "imperial_current_user",
  PAYMENTS: "imperial_payments",
};

// Users Service
// NOTE: this client-side service uses localStorage for demo purposes.
//       in a real deployment you would call the backend API endpoints
//       (e.g. GET /api/users) and remove the localStorage fallback.
export const usersService = {
  getAll: (): User[] => {
    if (typeof window === "undefined") return [];
    const data = localStorage.getItem(STORAGE_KEYS.USERS);
    return data ? JSON.parse(data) : [];
  },

  createUser: (user: RegisterUserInput): User => {
    const baseUser = {
      ...user,
      id: `user_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };

    const newUser: User =
      user.role === "coach"
        ? ({
            ...baseUser,
            specialty: user.specialty || "General Coaching",
            rating: user.rating ?? 5,
            reviews: user.reviews ?? 0,
            hourlyRate: user.hourlyRate ?? 3500,
            availability: user.availability || "Mon-Fri, 8 AM - 6 PM",
            students: user.students || [],
            earnings: user.earnings ?? 0,
          } as unknown as User)
        : ({
            ...baseUser,
            level: user.level || "Beginner",
            bookedSessions: user.bookedSessions || [],
            registeredTournaments: user.registeredTournaments || [],
          } as unknown as User);

    const users = usersService.getAll();
    users.push(newUser);
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    }
    return newUser;
  },

  getUserById: (id: string): User | null => {
    const users = usersService.getAll();
    return users.find((u) => u.id === id) || null;
  },

  getUserByEmail: (email: string): User | null => {
    const users = usersService.getAll();
    return users.find((u) => u.email === email) || null;
  },

  updateUser: (
    id: string,
    updates: Partial<User> & Partial<Coach> & Partial<Player>
  ): User | null => {
    const users = usersService.getAll();
    const index = users.findIndex((u) => u.id === id);
    if (index === -1) return null;
    users[index] = { ...users[index], ...updates };
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      const currentUserRaw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      if (currentUserRaw) {
        const currentUser = JSON.parse(currentUserRaw) as User;
        if (currentUser.id === id) {
          localStorage.setItem(
            STORAGE_KEYS.CURRENT_USER,
            JSON.stringify(users[index])
          );
        }
      }
    }
    return users[index];
  },

  getCoaches: (): Coach[] => {
    const users = usersService.getAll();
    return users
      .filter((u) => u.role === "coach")
      .map(
        (coach) =>
          ({
            ...coach,
            specialty:
              (coach as Partial<Coach>).specialty || "General Coaching",
            rating: (coach as Partial<Coach>).rating ?? 5,
            reviews: (coach as Partial<Coach>).reviews ?? 0,
            hourlyRate: (coach as Partial<Coach>).hourlyRate ?? 3500,
            availability:
              (coach as Partial<Coach>).availability ||
              "Mon-Fri, 8 AM - 6 PM",
            students: (coach as Partial<Coach>).students || [],
            earnings: (coach as Partial<Coach>).earnings ?? 0,
          }) as Coach
      );
  },

  getPlayers: (): Player[] => {
    const users = usersService.getAll();
    return users.filter((u) => u.role === "player") as Player[];
  },

  getTrainees: (): Player[] => {
    const users = usersService.getAll();
    return users.filter((u) => u.role === "trainee") as Player[];
  },
};

// Sessions Service
// TODO: integrate with server API (/api/sessions) instead of localStorage
export const sessionsService = {
  getAll: (): CoachingSession[] => {
    if (typeof window === "undefined") return [];
    const data = localStorage.getItem(STORAGE_KEYS.SESSIONS);
    return data ? JSON.parse(data) : [];
  },

  createSession: (
    session: Omit<CoachingSession, "id">
  ): CoachingSession => {
    const newSession: CoachingSession = {
      ...session,
      id: `session_${Date.now()}`,
      // ensure mediaUrls array exists even if not supplied
      mediaUrls: session.mediaUrls || [],
    };
    const sessions = sessionsService.getAll();
    sessions.push(newSession);
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
    }
    return newSession;
  },

  getByCoachId: (coachId: string): CoachingSession[] => {
    const sessions = sessionsService.getAll();
    return sessions.filter((s) => s.coachId === coachId);
  },

  getByPlayerId: (playerId: string): CoachingSession[] => {
    const sessions = sessionsService.getAll();
    return sessions.filter((s) => s.playerId === playerId);
  },

  updateSession: (
    id: string,
    updates: Partial<CoachingSession>
  ): CoachingSession | null => {
    const sessions = sessionsService.getAll();
    const index = sessions.findIndex((s) => s.id === id);
    if (index === -1) return null;
    sessions[index] = { ...sessions[index], ...updates };
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
    }
    return sessions[index];
  },

  deleteSession: (id: string): boolean => {
    const sessions = sessionsService.getAll();
    const filtered = sessions.filter((s) => s.id !== id);
    if (filtered.length < sessions.length) {
      if (typeof window !== "undefined") {
        localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(filtered));
      }
      return true;
    }
    return false;
  },
};

// Tournaments Service
// TODO: integrate with server API (/api/tournaments) instead of localStorage
export const tournamentsService = {
  getAll: (): Tournament[] => {
    if (typeof window === "undefined") return [];
    const data = localStorage.getItem(STORAGE_KEYS.TOURNAMENTS);
    return data ? JSON.parse(data) : [];
  },

  createTournament: (
    tournament: Omit<Tournament, "id">
  ): Tournament => {
    const newTournament: Tournament = {
      ...tournament,
      id: `tournament_${Date.now()}`,
      // start with empty media array if not provided
      mediaUrls: tournament.mediaUrls || [],
    };
    const tournaments = tournamentsService.getAll();
    tournaments.push(newTournament);
    if (typeof window !== "undefined") {
      localStorage.setItem(
        STORAGE_KEYS.TOURNAMENTS,
        JSON.stringify(tournaments)
      );
    }
    return newTournament;
  },

  getByCoachId: (coachId: string): Tournament[] => {
    const tournaments = tournamentsService.getAll();
    return tournaments.filter((t) => t.coachId === coachId);
  },

  getTournamentById: (id: string): Tournament | null => {
    const tournaments = tournamentsService.getAll();
    return tournaments.find((t) => t.id === id) || null;
  },

  registerPlayer: (
    tournamentId: string,
    playerId: string
  ): Tournament | null => {
    const tournaments = tournamentsService.getAll();
    const index = tournaments.findIndex((t) => t.id === tournamentId);
    if (index === -1) return null;
    if (!tournaments[index].registeredPlayers.includes(playerId)) {
      tournaments[index].registeredPlayers.push(playerId);
      tournaments[index].participants += 1;
      if (typeof window !== "undefined") {
        localStorage.setItem(
          STORAGE_KEYS.TOURNAMENTS,
          JSON.stringify(tournaments)
        );
      }
    }
    return tournaments[index];
  },

  unregisterPlayer: (
    tournamentId: string,
    playerId: string
  ): Tournament | null => {
    const tournaments = tournamentsService.getAll();
    const index = tournaments.findIndex((t) => t.id === tournamentId);
    if (index === -1) return null;
    const playerIndex =
      tournaments[index].registeredPlayers.indexOf(playerId);
    if (playerIndex > -1) {
      tournaments[index].registeredPlayers.splice(playerIndex, 1);
      tournaments[index].participants -= 1;
      if (typeof window !== "undefined") {
        localStorage.setItem(
          STORAGE_KEYS.TOURNAMENTS,
          JSON.stringify(tournaments)
        );
      }
    }
    return tournaments[index];
  },

  updateTournament: (
    id: string,
    updates: Partial<Tournament>
  ): Tournament | null => {
    const tournaments = tournamentsService.getAll();
    const index = tournaments.findIndex((t) => t.id === id);
    if (index === -1) return null;
    tournaments[index] = { ...tournaments[index], ...updates };
    if (typeof window !== "undefined") {
      localStorage.setItem(
        STORAGE_KEYS.TOURNAMENTS,
        JSON.stringify(tournaments)
      );
    }
    return tournaments[index];
  },
};

// Auth Service
export const authService = {
  register: (user: RegisterUserInput): User => {
    const existingUser = usersService.getUserByEmail(user.email);
    if (existingUser) {
      throw new Error("Email already registered");
    }
    return usersService.createUser(user);
  },

  login: (email: string, _password: string): User | null => {
    // In a real app, password would be hashed and verified
    const user = usersService.getUserByEmail(email);
    if (user) {
      if (typeof window !== "undefined") {
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
      }
      return user;
    }
    return null;
  },

  logout: (): void => {
    if (typeof window !== "undefined") {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  },

  getCurrentUser: (): User | null => {
    if (typeof window === "undefined") return null;
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  },

  isAuthenticated: (): boolean => {
    return authService.getCurrentUser() !== null;
  },
};

// Payments Service
// TODO: integrate with server API (/api/payments) instead of localStorage
export const paymentsService = {
  getAll: (): Payment[] => {
    if (typeof window === "undefined") return [];
    const data = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    return data ? JSON.parse(data) : [];
  },

  createPayment: (
    payment: Omit<Payment, "id" | "date">
  ): Payment => {
    const newPayment: Payment = {
      ...payment,
      id: `payment_${Date.now()}`,
      date: new Date().toISOString(),
    };
    const payments = paymentsService.getAll();
    payments.push(newPayment);
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    }
    return newPayment;
  },

  getByUserId: (userId: string): Payment[] => {
    const payments = paymentsService.getAll();
    return payments.filter((p) => p.userId === userId);
  },

  updatePaymentStatus: (
    id: string,
    status: "Pending" | "Completed" | "Failed"
  ): Payment | null => {
    const payments = paymentsService.getAll();
    const index = payments.findIndex((p) => p.id === id);
    if (index === -1) return null;
    payments[index].status = status;
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    }
    return payments[index];
  },
};
