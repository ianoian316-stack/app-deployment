"use client";

import Link from "next/link";
import { useState } from "react";
import Image from "next/image";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import { authService } from "@/lib/services";

export default function LoginPage() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }));

    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      nextErrors.email = "Valid email is required";
    }
    if (!formData.password) {
      nextErrors.password = "Password is required";
    }

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    setIsLoading(true);
    const success = login(formData.email, formData.password);
    setIsLoading(false);

    if (!success) {
      setErrors({ email: "Invalid email or password" });
      return;
    }

    const currentUser = authService.getCurrentUser();
    if (!currentUser) {
      setErrors({ email: "Could not load account after login" });
      return;
    }

    router.push(
      currentUser.role === "coach"
        ? "/coaches/dashboard"
        : "/players/dashboard"
    );
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,#dbeafe_0%,#dcfce7_45%,#f8fafc_100%)] py-12 px-6">
      <div className="max-w-md mx-auto bg-white rounded-2xl shadow-xl border border-sky-100 p-8">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-3">
            <Image src="/icon.svg" alt="Imperial Tennis" width={48} height={48} />
          </div>
          <h1 className="text-4xl font-black tracking-tight text-sky-800 mb-2">
            IMPERIAL TENNIS
          </h1>
          <p className="text-slate-600">Sign in to continue</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email Address"
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
              errors.email ? "border-red-500" : "border-slate-300"
            }`}
          />
          {errors.email && <p className="text-sm text-red-600">{errors.email}</p>}

          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password"
            className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500 ${
              errors.password ? "border-red-500" : "border-slate-300"
            }`}
          />
          {errors.password && (
            <p className="text-sm text-red-600">{errors.password}</p>
          )}

          <div className="flex items-center justify-between text-sm">
            <label className="flex items-center gap-2 text-slate-600">
              <input
                type="checkbox"
                name="rememberMe"
                checked={formData.rememberMe}
                onChange={handleChange}
              />
              Remember me
            </label>
            <Link href="/auth/register" className="text-sky-700 hover:underline">
              Need an account?
            </Link>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-lg font-semibold text-white bg-gradient-to-r from-sky-600 to-emerald-600 hover:from-sky-700 hover:to-emerald-700 disabled:opacity-60"
          >
            {isLoading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <div className="mt-6 bg-sky-50 border border-sky-200 rounded-lg p-4 text-sm">
          <p className="font-semibold text-sky-900 mb-1">Demo Accounts</p>
          <p className="text-sky-800">coach@demo.com</p>
          <p className="text-sky-800">player@demo.com</p>
          <p className="text-sky-800">trainee@demo.com</p>
          <p className="text-sky-800">Password: any value</p>
        </div>
      </div>
    </div>
  );
}
