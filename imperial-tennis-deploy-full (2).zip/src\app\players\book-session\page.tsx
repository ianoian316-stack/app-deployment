"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import { usersService, sessionsService, paymentsService } from "@/lib/services";
import { Coach } from "@/lib/types";
import { initializeDemoData } from "@/lib/demoData";

export default function BookSessionPage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [coaches, setCoaches] = useState<Coach[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [bookingMode, setBookingMode] = useState<string | null>(null);
  const [bookingData, setBookingData] = useState({
    date: "",
    time: "10:00",
    duration: 60,
  });

  useEffect(() => {
    initializeDemoData();
  }, []);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push("/auth/login");
    }
  }, [isLoading, isAuthenticated, router]);

  useEffect(() => {
    if (!user) return;
    if (user.role === "player" || user.role === "trainee") {
      setCoaches(usersService.getCoaches() as Coach[]);
    }
    setDataLoading(false);
  }, [user]);

  if (isLoading || dataLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (
    !isAuthenticated ||
    !user ||
    (user.role !== "player" && user.role !== "trainee")
  ) {
    return null;
  }

  const handleBookSession = async (coachId: string) => {
    if (!bookingData.date || !bookingData.time) {
      alert("Please select a date and time");
      return;
    }

    const coach = coaches.find((item) => item.id === coachId);
    if (!coach) return;
    const sessionRate = Number(coach.hourlyRate || 0);
    if (!sessionRate || sessionRate <= 0) {
      alert("Coach rate is not configured yet. Ask coach to update profile.");
      return;
    }

    try {
      const checkoutRes = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: Math.round(sessionRate * 100),
          currency: "usd",
          metadata: { coachId, playerId: user.id },
        }),
      });
      const checkoutData = await checkoutRes.json();
      console.log("client secret", checkoutData.clientSecret);
    } catch (error) {
      console.error("payment intent error", error);
    }

    const session = sessionsService.createSession({
      coachId,
      playerId: user.id,
      coachName: coach.name,
      playerName: user.name,
      date: bookingData.date,
      time: bookingData.time,
      type: "One-on-One",
      duration: bookingData.duration,
      status: "Confirmed",
      amount: sessionRate,
      mediaUrls: [],
    });

    if (!session) return;

      paymentsService.createPayment({
        userId: coachId,
        amount: sessionRate,
        type: "coaching_fee",
        status: "Completed",
        description: `Coaching fee from ${user.name}`,
    });

    alert("Session booked successfully.");
    setBookingMode(null);
    setBookingData({ date: "", time: "10:00", duration: 60 });
    router.push("/players/dashboard");
  };

  const demoCoaches: Coach[] = [
    {
      id: "coach_1",
      name: "Coach Alex",
      email: "coach@demo.com",
      phone: "+1 (555) 123-4567",
      role: "coach",
      createdAt: new Date().toISOString(),
      specialty: "Advanced Techniques",
      rating: 4.9,
      reviews: 156,
      hourlyRate: 5000,
      availability: "Mon-Wed, 10-11 AM",
      students: [],
      earnings: 0,
      contactDetails: {
        whatsapp: "+1 (555) 123-4567",
        preferredChannel: "In-app chat",
      },
    },
    {
      id: "coach_2",
      name: "Coach Maria",
      email: "maria@example.com",
      phone: "+1 (555) 234-5678",
      role: "coach",
      createdAt: new Date().toISOString(),
      specialty: "Beginner Fundamentals",
      rating: 4.8,
      reviews: 89,
      hourlyRate: 4000,
      availability: "Tue-Thu, 2-5 PM",
      students: [],
      earnings: 0,
      contactDetails: {
        whatsapp: "+1 (555) 234-5678",
      },
    },
  ];

  const displayCoaches = coaches.length > 0 ? coaches : demoCoaches;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-primary text-white py-8 px-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Book a Coaching Session</h1>
          <p className="text-lg opacity-90">
            Choose from experienced coaches and schedule your session.
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayCoaches.map((coach) => (
            <div key={coach.id} className="card flex flex-col">
              <div className="text-5xl mb-4 text-center">Coach</div>

              <h3 className="text-xl font-bold text-gray-900 mb-1">{coach.name}</h3>
              <p className="text-accent-600 font-semibold mb-3">{coach.specialty}</p>

              <div className="flex items-center gap-2 mb-3">
                <span className="text-yellow-500">★</span>
                <span className="font-semibold text-gray-900">{coach.rating}</span>
                <span className="text-gray-600">({coach.reviews} reviews)</span>
              </div>

              <p className="text-2xl font-bold text-primary-600 mb-2">
                KES {coach.hourlyRate.toLocaleString()}
                <span className="text-sm text-gray-600">/hour</span>
              </p>

              <p className="text-gray-600 mb-3">Availability: {coach.availability}</p>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 mb-4 text-sm">
                <p className="font-semibold text-slate-900 mb-1">Contact Details</p>
                <p className="text-slate-700">Email: {coach.email}</p>
                <p className="text-slate-700">Phone: {coach.phone}</p>
                {coach.contactDetails?.whatsapp && (
                  <p className="text-slate-700">
                    WhatsApp: {coach.contactDetails.whatsapp}
                  </p>
                )}
                {coach.contactDetails?.telegram && (
                  <p className="text-slate-700">
                    Telegram: {coach.contactDetails.telegram}
                  </p>
                )}
                {coach.contactDetails?.preferredChannel && (
                  <p className="text-slate-700">
                    Preferred: {coach.contactDetails.preferredChannel}
                  </p>
                )}
                {coach.contactDetails?.note && (
                  <p className="text-slate-700">{coach.contactDetails.note}</p>
                )}
              </div>

              {bookingMode === coach.id ? (
                <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Date</label>
                    <input
                      type="date"
                      value={bookingData.date}
                      onChange={(e) =>
                        setBookingData((prev) => ({ ...prev, date: e.target.value }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">Time</label>
                    <input
                      type="time"
                      value={bookingData.time}
                      onChange={(e) =>
                        setBookingData((prev) => ({ ...prev, time: e.target.value }))
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    />
                  </div>
                  <button
                    onClick={() => {
                      void handleBookSession(coach.id);
                    }}
                    className="w-full btn-primary text-sm"
                  >
                    Confirm Booking
                  </button>
                  <button
                    onClick={() => setBookingMode(null)}
                    className="w-full btn-secondary text-sm"
                  >
                    Cancel
                  </button>
                  <Link
                    href={`/messages?userId=${coach.id}`}
                    className="w-full text-center px-4 py-2 text-sm rounded-lg border border-sky-500 text-sky-700 hover:bg-sky-50 block"
                  >
                    Message Coach
                  </Link>
                </div>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={() => setBookingMode(coach.id)}
                    className="btn-primary w-full"
                  >
                    Book Session
                  </button>
                  <Link
                    href={`/messages?userId=${coach.id}`}
                    className="w-full text-center px-4 py-2 text-sm rounded-lg border border-sky-500 text-sky-700 hover:bg-sky-50 block"
                  >
                    Message Coach
                  </Link>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
