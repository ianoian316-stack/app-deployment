export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold">Privacy Policy</h1>
          <p className="text-lg opacity-90 mt-2">
            Last updated: February 25, 2026
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="bg-white rounded-lg shadow p-8 space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Introduction
            </h2>
            <p className="text-gray-600">
              IMPERIAL TENNIS (&quot;we&quot;, &quot;us&quot;, &quot;our&quot;, or
              &quot;Company&quot;) operates the IMPERIAL TENNIS website and
              mobile application (the &quot;Service&quot;).
            </p>
            <p className="text-gray-600 mt-4">
              This page informs you of our policies regarding the collection,
              use, and disclosure of personal data when you use our Service and
              the choices you have associated with that data.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Information Collection And Use
            </h2>
            <p className="text-gray-600 mb-4">We collect several different types of information for various purposes to provide and improve our Service to you.</p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex gap-3">
                <span>•</span>
                <span>
                  <strong>Personal Data:</strong> Email address, name, phone
                  number, payment information
                </span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>
                  <strong>Usage Data:</strong> Browser type, IP address, pages
                  visited, time and date of visits
                </span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>
                  <strong>Profile Data:</strong> Tennis experience, coaching
                  credentials, availability
                </span>
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Use Of Data
            </h2>
            <p className="text-gray-600 mb-4">
              IMPERIAL TENNIS uses the collected data for various purposes:
            </p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex gap-3">
                <span>•</span>
                <span>To provide and maintain the Service</span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>To notify you about changes to our Service</span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>
                  To allow you to participate in interactive features of our
                  Service
                </span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>To provide customer service and support</span>
              </li>
              <li className="flex gap-3">
                <span>•</span>
                <span>To gather analysis or valuable information</span>
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Security Of Data
            </h2>
            <p className="text-gray-600">
              The security of your data is important to us, but remember that
              no method of transmission over the Internet or method of
              electronic storage is 100% secure. While we strive to use
              commercially acceptable means to protect your Personal Data, we
              cannot guarantee its absolute security.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Us</h2>
            <p className="text-gray-600">
              If you have any questions about this Privacy Policy, please
              contact us at:
            </p>
            <p className="text-gray-600 mt-4">
              Email: privacy@imperialtennis.com
              <br />
              Address: 123 Tennis Lane, Sports City, ST 12345
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
