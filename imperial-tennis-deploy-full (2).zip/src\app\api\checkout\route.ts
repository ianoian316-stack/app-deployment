import Stripe from "stripe";

const stripeSecret = process.env.STRIPE_SECRET_KEY;

const getStripe = () => {
  if (!stripeSecret) return null;
  return new Stripe(stripeSecret, { apiVersion: "2026-02-25.clover" });
};

export async function POST(req: Request) {
  try {
    const { amount, currency = "usd", metadata } = await req.json();
    const stripe = getStripe();

    if (!stripe) {
      return new Response(
        JSON.stringify({
          clientSecret: "demo_client_secret",
          message: "Stripe key not configured. Demo payment mode active.",
        }),
        { status: 200 }
      );
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
      metadata,
    });

    return new Response(
      JSON.stringify({ clientSecret: paymentIntent.client_secret }),
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Stripe error", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
    });
  }
}
