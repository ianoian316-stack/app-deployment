export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">About IMPERIAL TENNIS</h1>
          <p className="text-xl opacity-90">
            Revolutionizing how tennis coaches and players connect
          </p>
        </div>
      </div>

      {/* Mission Section */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 items-center mb-16">
            <div>
              <h2 className="text-3xl font-bold mb-4 text-gray-900">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 mb-4">
                IMPERIAL TENNIS is dedicated to connecting passionate tennis
                coaches with dedicated players worldwide. We believe that great
                coaching should be accessible to everyone, and every player
                deserves the opportunity to reach their full potential.
              </p>
              <p className="text-lg text-gray-600">
                Our platform simplifies the entire process - from finding the
                right coach to booking sessions, participating in tournaments,
                and managing payments.
              </p>
            </div>
            <div className="bg-gradient-primary rounded-lg p-8 text-center text-white h-64 flex items-center justify-center">
              <div>
                <div className="text-6xl mb-4">🎾</div>
                <p className="text-xl font-bold">Connected Community</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="bg-white py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="section-title text-center">Our Core Values</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="card text-center">
              <div className="text-5xl mb-4">🤝</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Community First
              </h3>
              <p className="text-gray-600">
                We&apos;re committed to building a supportive, inclusive community
                where coaches and players can thrive together.
              </p>
            </div>

            <div className="card text-center">
              <div className="text-5xl mb-4">✨</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Excellence
              </h3>
              <p className="text-gray-600">
                We strive for highest quality in everything we do, from features
                to customer service to safety.
              </p>
            </div>

            <div className="card text-center">
              <div className="text-5xl mb-4">🔒</div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Security & Trust
              </h3>
              <p className="text-gray-600">
                Your data and transactions are protected with industry-leading
                security measures.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="section-title text-center">Our Team</h2>
          <p className="text-center text-gray-600 max-w-2xl mx-auto mb-12">
            Passionate tennis enthusiasts and experienced tech professionals
            working together to build the best platform for the tennis community.
          </p>

          <div className="grid md:grid-cols-4 gap-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="card text-center">
                <div className="text-6xl mb-4">👤</div>
                <h3 className="text-lg font-bold text-gray-900 mb-1">
                  Team Member {i}
                </h3>
                <p className="text-gray-600 mb-3">Leadership</p>
                <p className="text-sm text-gray-500">
                  Passionate about tennis and community building.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-gradient-primary text-white py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Get In Touch</h2>
          <p className="text-xl opacity-90 mb-8">
            Have questions or suggestions? We&apos;d love to hear from you!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="btn-secondary">Contact Us</button>
            <button className="btn-primary">Send Feedback</button>
          </div>
        </div>
      </section>
    </div>
  );
}
