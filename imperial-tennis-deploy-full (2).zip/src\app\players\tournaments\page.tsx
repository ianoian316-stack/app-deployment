"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { tournamentsService, paymentsService } from "@/lib/services";
import { Tournament } from "@/lib/types";
import { initializeDemoData } from "@/lib/demoData";

export default function TournamentsPage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    initializeDemoData();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated) {
        router.push("/auth/login");
      }
    }
  }, [isLoading, isAuthenticated, router]);

  useEffect(() => {
    if (user) {
      if (user.role === "player" || user.role === "trainee") {
        const allTournaments = tournamentsService.getAll();
        setTournaments(allTournaments);
      }
      setDataLoading(false);
    }
  }, [user]);

  if (isLoading || dataLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (
    !isAuthenticated ||
    !user ||
    (user.role !== "player" && user.role !== "trainee")
  ) {
    return null;
  }

  const handleRegister = async (tournamentId: string) => {
    const tournament = tournaments.find((t) => t.id === tournamentId);
    if (!tournament) return;

    // create payment intent
    try {
      const checkoutRes = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: Math.round(tournament.entryFee * 100),
          currency: "usd",
          metadata: { coachId: tournament.coachId, playerId: user.id },
        }),
      });
      const checkoutData = await checkoutRes.json();
      console.log("tournament client secret", checkoutData.clientSecret);
    } catch (err) {
      console.error("payment intent error", err);
    }

    tournamentsService.registerPlayer(tournamentId, user.id);
    setTournaments(tournaments.map((t) =>
      t.id === tournamentId
        ? { ...t, registeredPlayers: [...t.registeredPlayers, user.id] }
        : t
    ));

    // record payment to coach for entry fee
    paymentsService.createPayment({
      userId: tournament.coachId,
      amount: tournament.entryFee,
      type: "tournament_entry",
      status: "Completed",
      description: `Entry fee for ${tournament.name} by ${user.name}`,
    });

    alert("Successfully registered for tournament!");
  };

  const handleUnregister = (tournamentId: string) => {
    tournamentsService.unregisterPlayer(tournamentId, user.id);
    setTournaments(tournaments.map((t) =>
      t.id === tournamentId
        ? {
            ...t,
            registeredPlayers: t.registeredPlayers.filter((p) => p !== user.id),
          }
        : t
    ));
    alert("Successfully unregistered from tournament!");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-8 px-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Tennis Tournaments</h1>
          <p className="text-lg opacity-90">
            Compete, participate, and win prizes
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="bg-white rounded-lg shadow p-6 mb-8 flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-semibold mb-2">Category</label>
            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
              <option>All Categories</option>
              <option>Open</option>
              <option>Beginner</option>
              <option>Women&apos;s</option>
              <option>Junior</option>
            </select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-semibold mb-2">Date</label>
            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
              <option>All Dates</option>
              <option>This Month</option>
              <option>Next Month</option>
              <option>Next 3 Months</option>
            </select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-semibold mb-2">Status</label>
            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg">
              <option>All Status</option>
              <option>Registration Open</option>
              <option>Registered</option>
              <option>Closed</option>
            </select>
          </div>
        </div>

        {/* Tournaments Grid */}
        <div className="space-y-6">
          {tournaments.map((tournament) => {
            const isRegistered = tournament.registeredPlayers.includes(user.id);
            return (
              <div
                key={tournament.id}
                className={`card flex flex-col md:flex-row justify-between items-start md:items-center gap-6 ${
                  isRegistered ? "border-l-4 border-l-accent-500" : ""
                }`}
              >
                <div className="flex-grow">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-2xl font-bold text-gray-900">
                      {tournament.name}
                    </h3>
                    {isRegistered && (
                      <span className="px-3 py-1 bg-accent-100 text-accent-700 rounded-full text-sm font-semibold">
                        Registered
                      </span>
                    )}
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600">📅 Date</p>
                      <p className="font-semibold text-gray-900">
                        {tournament.date}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">📍 Location</p>
                      <p className="font-semibold text-gray-900">
                        {tournament.location}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">💰 Prize Pool</p>
                      <p className="font-semibold text-accent-600">
                        KES {tournament.prizePool.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">👥 Participants</p>
                      <p className="font-semibold text-gray-900">
                        {tournament.participants}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <span className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-semibold">
                      {tournament.category}
                    </span>
                    <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-sm font-semibold">
                      KES {tournament.entryFee.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-2 w-full md:w-auto">
                  {isRegistered ? (
                    <>
                      <button className="btn-secondary">View Details</button>
                      <Link
                        href={`/messages?userId=${tournament.coachId}`}
                        className="px-4 py-2 text-center rounded-lg border border-sky-500 text-sky-700 hover:bg-sky-50 font-semibold"
                      >
                        Message Coach
                      </Link>
                      <button
                        onClick={() => handleUnregister(tournament.id)}
                        className="px-4 py-2 text-red-600 border-2 border-red-600 rounded-lg hover:bg-red-50 font-semibold"
                      >
                        Cancel Registration
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => handleRegister(tournament.id)}
                        className="btn-primary"
                      >
                        Register Now
                      </button>
                      <button className="btn-secondary">View Details</button>
                      <Link
                        href={`/messages?userId=${tournament.coachId}`}
                        className="px-4 py-2 text-center rounded-lg border border-sky-500 text-sky-700 hover:bg-sky-50 font-semibold"
                      >
                        Message Coach
                      </Link>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
