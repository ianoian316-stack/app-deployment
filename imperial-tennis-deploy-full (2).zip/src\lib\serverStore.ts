import { User, CoachingSession, Tournament, Payment } from "./types";

// simple in-memory store for API endpoints
export const users: User[] = [];
export const sessions: CoachingSession[] = [];
export const tournaments: Tournament[] = [];
export const payments: Payment[] = [];
