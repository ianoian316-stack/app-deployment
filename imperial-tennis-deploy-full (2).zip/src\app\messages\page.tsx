"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import { initializeDemoData } from "@/lib/demoData";
import { messagesService } from "@/lib/messagesService";
import { ChatConversation, ChatMessage, User } from "@/lib/types";
import { usersService } from "@/lib/services";

type DecryptedMessage = ChatMessage & { content: string };

const getOtherParticipantId = (conversation: ChatConversation, userId: string) =>
  conversation.participants.find((id) => id !== userId) || "";

const formatTime = (dateIso: string) =>
  new Date(dateIso).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

export default function MessagesPage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();

  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<string>("");
  const [messages, setMessages] = useState<DecryptedMessage[]>([]);
  const [draftMessage, setDraftMessage] = useState("");
  const [pageLoading, setPageLoading] = useState(true);

  const selectedConversation = useMemo(
    () => conversations.find((item) => item.id === selectedConversationId) || null,
    [conversations, selectedConversationId]
  );

  const selectedContact = useMemo(() => {
    if (!user || !selectedConversation) return null;
    const contactId = getOtherParticipantId(selectedConversation, user.id);
    return allUsers.find((item) => item.id === contactId) || null;
  }, [allUsers, selectedConversation, user]);

  const loadSidebarData = (authUser: User, currentConversationId?: string) => {
    const users = usersService.getAll().filter((item) => item.id !== authUser.id);
    const userConversations = messagesService.getUserConversations(authUser.id);

    setAllUsers(users);
    setConversations(userConversations);

    if (currentConversationId) {
      setSelectedConversationId(currentConversationId);
      return;
    }

    if (!selectedConversationId && userConversations.length > 0) {
      setSelectedConversationId(userConversations[0].id);
    }
  };

  useEffect(() => {
    initializeDemoData();
  }, []);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push("/auth/login");
    }
  }, [isAuthenticated, isLoading, router]);

  useEffect(() => {
    if (!user) return;
    loadSidebarData(user);
    setPageLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  useEffect(() => {
    let cancelled = false;

    const loadMessages = async () => {
      if (!selectedConversationId) {
        setMessages([]);
        return;
      }
      if (user) {
        messagesService.markConversationAsRead(selectedConversationId, user.id);
      }
      const decrypted = await messagesService.getDecryptedMessages(
        selectedConversationId
      );
      if (!cancelled) {
        setMessages(decrypted);
      }
    };

    void loadMessages();
    const interval = setInterval(() => {
      void loadMessages();
    }, 2000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [selectedConversationId, user]);

  const startConversation = async (targetUserId: string) => {
    if (!user) return;
    const conversation = await messagesService.getOrCreateDirectConversation(
      user.id,
      targetUserId
    );
    loadSidebarData(user, conversation.id);
  };

  useEffect(() => {
    if (typeof window === "undefined") return;
    const search = new URLSearchParams(window.location.search);
    const targetUserId = search.get("userId");
    if (!user || !targetUserId || targetUserId === user.id) return;
    void startConversation(targetUserId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleSendMessage = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !selectedConversationId) return;
    const trimmed = draftMessage.trim();
    if (!trimmed) return;

    await messagesService.sendMessage(selectedConversationId, user.id, trimmed);
    setDraftMessage("");
    loadSidebarData(user, selectedConversationId);
    const decrypted = await messagesService.getDecryptedMessages(selectedConversationId);
    setMessages(decrypted);
  };

  if (isLoading || pageLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated || !user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-gradient-primary text-white py-8 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Direct Messages</h1>
          <p className="text-lg opacity-90">
            Private end-to-end encrypted conversations for players, trainees, and
            coaches.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 grid lg:grid-cols-[320px_1fr] gap-6">
        <aside className="space-y-6">
          <section className="card">
            <h2 className="text-lg font-bold text-slate-900 mb-3">Active Chats</h2>
            {conversations.length === 0 ? (
              <p className="text-sm text-slate-600">No conversations yet.</p>
            ) : (
              <div className="space-y-2">
                {conversations.map((conversation) => {
                  const otherId = getOtherParticipantId(conversation, user.id);
                  const otherUser = allUsers.find((item) => item.id === otherId);
                  if (!otherUser) return null;

                  return (
                    <button
                      key={conversation.id}
                      onClick={() => setSelectedConversationId(conversation.id)}
                      className={`w-full text-left p-3 rounded-lg border transition ${
                        selectedConversationId === conversation.id
                          ? "border-sky-400 bg-sky-50"
                          : "border-slate-200 bg-white hover:border-sky-300"
                      }`}
                    >
                      <p className="font-semibold text-slate-900">{otherUser.name}</p>
                      <p className="text-xs text-slate-500 capitalize">{otherUser.role}</p>
                    </button>
                  );
                })}
              </div>
            )}
          </section>

          <section className="card">
            <h2 className="text-lg font-bold text-slate-900 mb-3">Start New Chat</h2>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {allUsers.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    void startConversation(item.id);
                  }}
                  className="w-full text-left p-3 rounded-lg border border-slate-200 bg-white hover:border-emerald-300 transition"
                >
                  <p className="font-semibold text-slate-900">{item.name}</p>
                  <p className="text-xs text-slate-500 capitalize">{item.role}</p>
                </button>
              ))}
            </div>
          </section>
        </aside>

        <section className="card flex flex-col min-h-[520px]">
          {selectedConversation && selectedContact ? (
            <>
              <header className="border-b border-slate-200 pb-4 mb-4">
                <h2 className="text-xl font-bold text-slate-900">{selectedContact.name}</h2>
                <p className="text-sm text-slate-600 capitalize">{selectedContact.role}</p>
                <div className="mt-2 text-sm text-slate-700 space-y-1">
                  <p>Email: {selectedContact.email}</p>
                  <p>Phone: {selectedContact.phone}</p>
                  {selectedContact.contactDetails?.whatsapp && (
                    <p>WhatsApp: {selectedContact.contactDetails.whatsapp}</p>
                  )}
                  {selectedContact.contactDetails?.telegram && (
                    <p>Telegram: {selectedContact.contactDetails.telegram}</p>
                  )}
                </div>
              </header>

              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {messages.length === 0 ? (
                  <p className="text-slate-600 text-sm">
                    No messages yet. Start your conversation.
                  </p>
                ) : (
                  messages.map((message) => {
                    const isMe = message.senderId === user.id;
                    return (
                      <div
                        key={message.id}
                        className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[75%] px-4 py-2 rounded-xl ${
                            isMe
                              ? "bg-sky-600 text-white"
                              : "bg-emerald-100 text-slate-900"
                          }`}
                        >
                          <p className="whitespace-pre-wrap break-words">
                            {message.content}
                          </p>
                          <p
                            className={`text-[11px] mt-1 ${
                              isMe ? "text-sky-100" : "text-slate-500"
                            }`}
                          >
                            {formatTime(message.createdAt)}
                          </p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              <form onSubmit={handleSendMessage} className="mt-4 border-t border-slate-200 pt-4">
                <div className="flex gap-2">
                  <input
                    value={draftMessage}
                    onChange={(e) => setDraftMessage(e.target.value)}
                    placeholder="Write an encrypted message..."
                    className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                  <button type="submit" className="btn-primary">
                    Send
                  </button>
                </div>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-600">
              Select a chat to start messaging.
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
