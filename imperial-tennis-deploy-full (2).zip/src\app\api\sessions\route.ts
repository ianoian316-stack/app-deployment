import { NextResponse } from "next/server";
import { sessions } from "@/lib/serverStore";
import { CoachingSession } from "@/lib/types";

export async function GET() {
  return NextResponse.json(sessions);
}

export async function POST(req: Request) {
  const data = await req.json();
  const newSession: CoachingSession = {
    ...data,
    id: `session_${Date.now()}`,
  };
  sessions.push(newSession);
  return NextResponse.json(newSession);
}
