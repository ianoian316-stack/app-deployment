"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import { paymentsService } from "@/lib/services";
import { initializeDemoData } from "@/lib/demoData";

interface EarningRecord {
  id: string;
  date: string;
  description: string;
  paidBy: string;
  type: string;
  amount: number;
  status: string;
}

const extractPayerName = (description: string) => {
  const byMatch = description.match(/by\s+(.+)$/i);
  if (byMatch?.[1]) return byMatch[1].trim();
  const fromMatch = description.match(/from\s+(.+)$/i);
  if (fromMatch?.[1]) return fromMatch[1].trim();
  return "N/A";
};

export default function EarningsPage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [earnings, setEarnings] = useState<EarningRecord[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    coaching: 0,
    tournaments: 0,
    pending: 0,
  });

  useEffect(() => {
    initializeDemoData();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthenticated || user?.role !== "coach") {
        router.push("/auth/login");
      }
    }
  }, [isLoading, isAuthenticated, user, router]);

  useEffect(() => {
    if (user) {
      if (user.role === "coach") {
        // revenue now comes from payments stored in the system
        const allPayments = paymentsService.getAll();
        const coachPayments = allPayments.filter((p) => p.userId === user.id);

        // break down by type
        const coachingPayments = coachPayments.filter(
          (p) => p.type === "coaching_fee"
        );
        const tournamentPayments = coachPayments.filter(
          (p) => p.type === "tournament_entry"
        );

        const sessionEarnings: EarningRecord[] = coachingPayments.map((p) => ({
          id: p.id,
          date: p.date,
          description: p.description,
          paidBy: extractPayerName(p.description),
          type: "Coaching Fee",
          amount: p.amount,
          status: p.status,
        }));

        const tournamentEarnings: EarningRecord[] = tournamentPayments.map((p) => ({
          id: p.id,
          date: p.date,
          description: p.description,
          paidBy: extractPayerName(p.description),
          type: "Tournament Entry",
          amount: p.amount,
          status: p.status,
        }));

        const totalCoaching = coachingPayments.reduce((sum, p) => sum + p.amount, 0);
        const totalTournament = tournamentPayments.reduce((sum, p) => sum + p.amount, 0);
        const totalPending = coachPayments
          .filter((p) => p.status === "Pending")
          .reduce((sum, p) => sum + p.amount, 0);

        setEarnings([...sessionEarnings, ...tournamentEarnings]);
        setStats({
          total: totalCoaching + totalTournament,
          coaching: totalCoaching,
          tournaments: totalTournament,
          pending: totalPending,
        });
      }
      setDataLoading(false);
    }
  }, [user]);

  if (isLoading || dataLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  if (!isAuthenticated || !user || user.role !== "coach") {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-8 px-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Your Earnings</h1>
          <p className="text-lg opacity-90">
            Track your coaching fees and tournament revenue
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <div className="card bg-gradient-to-br from-primary-50 to-primary-100">
            <p className="text-gray-600 text-sm font-semibold mb-2">
              Total Earnings
            </p>
            <div className="text-4xl font-bold text-primary-600">
              KES {stats.total.toLocaleString()}
            </div>
          </div>

          <div className="card bg-gradient-to-br from-accent-50 to-accent-100">
            <p className="text-gray-600 text-sm font-semibold mb-2">
              From Coaching
            </p>
            <div className="text-4xl font-bold text-accent-600">
              KES {stats.coaching.toLocaleString()}
            </div>
          </div>

          <div className="card bg-gradient-to-br from-blue-50 to-blue-100">
            <p className="text-gray-600 text-sm font-semibold mb-2">
              From Tournaments
            </p>
            <div className="text-4xl font-bold text-blue-600">
              KES {stats.tournaments.toLocaleString()}
            </div>
          </div>

          <div className="card bg-gradient-to-br from-orange-50 to-orange-100">
            <p className="text-gray-600 text-sm font-semibold mb-2">
              Pending Payments
            </p>
            <div className="text-4xl font-bold text-orange-600">
              KES {stats.pending.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Earnings Table */}
        <section className="card">
          <h2 className="text-2xl font-bold mb-6 text-gray-900">
            Recent Transactions
          </h2>

          {earnings.length === 0 ? (
            <p className="text-center py-8 text-gray-600">
              No earnings recorded yet. Start coaching sessions to earn!
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">
                      Date
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">
                      Description
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">
                      Paid By
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">
                      Type
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">
                      Amount
                    </th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {earnings.map((earning) => (
                    <tr
                      key={earning.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <td className="px-6 py-4 text-gray-900">{earning.date}</td>
                      <td className="px-6 py-4 text-gray-900">
                        {earning.description}
                      </td>
                      <td className="px-6 py-4 text-gray-900">
                        {earning.paidBy}
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-semibold">
                          {earning.type}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-lg font-bold text-gray-900">
                        KES {earning.amount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-semibold ${
                            earning.status === "Completed"
                              ? "bg-accent-100 text-accent-700"
                              : "bg-orange-100 text-orange-700"
                          }`}
                        >
                          {earning.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="mt-12">
          <div className="card">
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              Statement Summary
            </h3>
            <p className="text-gray-600">
              The app records who paid and when. Payouts are handled by your
              connected payment provider directly to your bank account.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
