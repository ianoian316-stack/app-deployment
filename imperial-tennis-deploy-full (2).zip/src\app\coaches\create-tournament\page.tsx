"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import { tournamentsService } from "@/lib/services";
import { initializeDemoData } from "@/lib/demoData";

export default function CreateTournamentPage() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formData, setFormData] = useState({
    name: "",
    date: "",
    location: "",
    category: "Open",
    prizePool: "",
    entryFee: "",
    participants: "",
    description: "",
    rules: "",
  });

  useEffect(() => {
    initializeDemoData();
  }, []);

  useEffect(() => {
    if (!isLoading && (!isAuthenticated || user?.role !== "coach")) {
      router.push("/auth/login");
    }
  }, [isLoading, isAuthenticated, user, router]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const nextErrors: Record<string, string> = {};
    if (!formData.name.trim()) nextErrors.name = "Tournament name is required";
    if (!formData.date) nextErrors.date = "Date is required";
    if (!formData.location.trim()) nextErrors.location = "Location is required";
    if (!formData.prizePool || Number(formData.prizePool) < 0) {
      nextErrors.prizePool = "Enter a valid prize pool";
    }
    if (!formData.entryFee || Number(formData.entryFee) < 0) {
      nextErrors.entryFee = "Enter a valid entry fee";
    }
    if (!formData.participants || Number(formData.participants) < 2) {
      nextErrors.participants = "At least 2 participants are required";
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!validateForm()) return;

    setIsSubmitting(true);
    tournamentsService.createTournament({
      name: formData.name,
      coachId: user.id,
      date: formData.date,
      location: formData.location,
      category: formData.category,
      prizePool: Number(formData.prizePool),
      entryFee: Number(formData.entryFee),
      participants: Number(formData.participants),
      description: formData.description || "Tournament details will be shared soon.",
      rules: formData.rules || "Standard tournament rules apply.",
      status: "Active",
      registeredPlayers: [],
      mediaUrls: [],
    });

    setIsSubmitting(false);
    alert("Tournament created and published successfully.");
    router.push("/coaches/dashboard");
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated || !user || user.role !== "coach") {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-primary text-white py-8 px-6">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Create Tournament</h1>
          <p className="text-lg opacity-90">
            Set details and publish your tournament for players and trainees.
          </p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-6 py-8">
        <form onSubmit={handleSubmit} className="card space-y-5">
          <div>
            <label className="block text-sm font-semibold mb-2">Tournament Name</label>
            <input
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg"
            />
            {errors.name && <p className="text-sm text-red-600 mt-1">{errors.name}</p>}
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2">Date</label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg"
              />
              {errors.date && <p className="text-sm text-red-600 mt-1">{errors.date}</p>}
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Category</label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg"
              >
                <option>Open</option>
                <option>Beginner</option>
                <option>Intermediate</option>
                <option>Advanced</option>
                <option>Junior</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Location</label>
            <input
              name="location"
              value={formData.location}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg"
            />
            {errors.location && (
              <p className="text-sm text-red-600 mt-1">{errors.location}</p>
            )}
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold mb-2">Prize Pool</label>
              <input
                type="number"
                name="prizePool"
                value={formData.prizePool}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg"
              />
              {errors.prizePool && (
                <p className="text-sm text-red-600 mt-1">{errors.prizePool}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Entry Fee</label>
              <input
                type="number"
                name="entryFee"
                value={formData.entryFee}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg"
              />
              {errors.entryFee && (
                <p className="text-sm text-red-600 mt-1">{errors.entryFee}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">Participants</label>
              <input
                type="number"
                name="participants"
                value={formData.participants}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg"
              />
              {errors.participants && (
                <p className="text-sm text-red-600 mt-1">{errors.participants}</p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Description</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Rules</label>
            <textarea
              name="rules"
              value={formData.rules}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full btn-primary disabled:opacity-60"
          >
            {isSubmitting ? "Publishing..." : "Publish Tournament"}
          </button>
        </form>
      </div>
    </div>
  );
}
