import { NextResponse } from "next/server";
import { payments } from "@/lib/serverStore";
import { Payment } from "@/lib/types";

export async function GET() {
  return NextResponse.json(payments);
}

export async function POST(req: Request) {
  const data = await req.json();
  const newPayment: Payment = {
    ...data,
    id: `payment_${Date.now()}`,
    date: new Date().toISOString(),
  };
  payments.push(newPayment);
  return NextResponse.json(newPayment);
}
