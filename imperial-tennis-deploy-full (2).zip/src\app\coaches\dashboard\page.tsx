"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthContext";
import { initializeDemoData } from "@/lib/demoData";
import { sessionsService, tournamentsService, usersService } from "@/lib/services";
import { CoachingSession, Tournament } from "@/lib/types";

export default function CoachDashboard() {
  const { user, isAuthenticated, isLoading, refreshUser } = useAuth();
  const router = useRouter();

  const [sessions, setSessions] = useState<CoachingSession[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [dataLoading, setDataLoading] = useState(true);

  const [profileForm, setProfileForm] = useState({
    specialty: "",
    hourlyRate: "",
    availability: "",
  });

  const [contactForm, setContactForm] = useState({
    phone: "",
    whatsapp: "",
    telegram: "",
    instagram: "",
    preferredChannel: "In-app chat",
    note: "",
  });

  useEffect(() => {
    initializeDemoData();
  }, []);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push("/auth/login");
    }
  }, [isLoading, isAuthenticated, router]);

  useEffect(() => {
    if (!user || user.role !== "coach") return;
    setSessions(sessionsService.getByCoachId(user.id));
    setTournaments(tournamentsService.getByCoachId(user.id));
    setProfileForm({
      specialty: user.specialty || "General Coaching",
      hourlyRate: String(user.hourlyRate ?? 3500),
      availability: user.availability || "Mon-Fri, 8 AM - 6 PM",
    });
    setContactForm({
      phone: user.phone || "",
      whatsapp: user.contactDetails?.whatsapp || "",
      telegram: user.contactDetails?.telegram || "",
      instagram: user.contactDetails?.instagram || "",
      preferredChannel: user.contactDetails?.preferredChannel || "In-app chat",
      note: user.contactDetails?.note || "",
    });
    setDataLoading(false);
  }, [user]);

  const stats = useMemo(() => {
    const recentEarnings = sessions.slice(0, 5).reduce((sum, session) => sum + session.amount, 0);
    const totalRevenue =
      sessions.reduce((sum, session) => sum + session.amount, 0) +
      tournaments.reduce((sum, tournament) => sum + tournament.participants * tournament.entryFee, 0);

    return {
      sessionCount: sessions.length,
      tournamentCount: tournaments.length,
      recentEarnings,
      totalRevenue,
      activeStudents: new Set(sessions.map((session) => session.playerId)).size,
    };
  }, [sessions, tournaments]);

  if (isLoading || dataLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated || !user || user.role !== "coach") {
    return null;
  }

  const saveProfessionalProfile = () => {
    const rate = Number(profileForm.hourlyRate);
    if (!profileForm.specialty.trim()) {
      alert("Please provide your coaching specialty.");
      return;
    }
    if (!rate || rate <= 0) {
      alert("Please provide a valid hourly rate.");
      return;
    }
    if (!profileForm.availability.trim()) {
      alert("Please provide your availability.");
      return;
    }

    const updated = usersService.updateUser(user.id, {
      specialty: profileForm.specialty.trim(),
      hourlyRate: rate,
      availability: profileForm.availability.trim(),
    });

    if (!updated) {
      alert("Unable to save professional profile.");
      return;
    }
    refreshUser();
    alert("Professional profile updated.");
  };

  const saveContactProfile = () => {
    const updated = usersService.updateUser(user.id, {
      phone: contactForm.phone.trim(),
      contactDetails: {
        whatsapp: contactForm.whatsapp.trim(),
        telegram: contactForm.telegram.trim(),
        instagram: contactForm.instagram.trim(),
        preferredChannel: contactForm.preferredChannel as
          | "Phone"
          | "WhatsApp"
          | "Email"
          | "In-app chat",
        note: contactForm.note.trim(),
      },
    });

    if (!updated) {
      alert("Unable to save contact profile.");
      return;
    }
    refreshUser();
    alert("Contact profile updated.");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-primary text-white py-8 px-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">Coach Dashboard</h1>
          <p className="text-lg opacity-90">Manage coaching, communication, and payments.</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-10">
        <div className="grid md:grid-cols-5 gap-4 mb-10">
          <div className="card">
            <p className="text-sm text-gray-600">Sessions</p>
            <p className="text-3xl font-bold text-primary-700">{stats.sessionCount}</p>
          </div>
          <div className="card">
            <p className="text-sm text-gray-600">Tournaments</p>
            <p className="text-3xl font-bold text-primary-700">{stats.tournamentCount}</p>
          </div>
          <div className="card">
            <p className="text-sm text-gray-600">Recent Earnings</p>
            <p className="text-3xl font-bold text-emerald-700">KES {stats.recentEarnings.toLocaleString()}</p>
          </div>
          <div className="card">
            <p className="text-sm text-gray-600">Total Revenue</p>
            <p className="text-3xl font-bold text-emerald-700">KES {stats.totalRevenue.toLocaleString()}</p>
          </div>
          <div className="card">
            <p className="text-sm text-gray-600">Active Students</p>
            <p className="text-3xl font-bold text-primary-700">{stats.activeStudents}</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-10">
          <section className="card">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Professional Profile</h2>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-semibold mb-2">Specialty</label>
                <input
                  value={profileForm.specialty}
                  onChange={(e) =>
                    setProfileForm((prev) => ({ ...prev, specialty: e.target.value }))
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Hourly Rate (KES)</label>
                <input
                  type="number"
                  value={profileForm.hourlyRate}
                  onChange={(e) =>
                    setProfileForm((prev) => ({ ...prev, hourlyRate: e.target.value }))
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">Availability</label>
                <input
                  value={profileForm.availability}
                  onChange={(e) =>
                    setProfileForm((prev) => ({ ...prev, availability: e.target.value }))
                  }
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg"
                />
              </div>
              <button onClick={saveProfessionalProfile} className="btn-primary">
                Save Professional Profile
              </button>
            </div>
          </section>

          <section className="card">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Profile</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              <input
                value={contactForm.phone}
                onChange={(e) => setContactForm((prev) => ({ ...prev, phone: e.target.value }))}
                placeholder="Phone"
                className="px-4 py-3 border border-gray-300 rounded-lg"
              />
              <input
                value={contactForm.whatsapp}
                onChange={(e) =>
                  setContactForm((prev) => ({ ...prev, whatsapp: e.target.value }))
                }
                placeholder="WhatsApp"
                className="px-4 py-3 border border-gray-300 rounded-lg"
              />
              <input
                value={contactForm.telegram}
                onChange={(e) =>
                  setContactForm((prev) => ({ ...prev, telegram: e.target.value }))
                }
                placeholder="Telegram"
                className="px-4 py-3 border border-gray-300 rounded-lg"
              />
              <input
                value={contactForm.instagram}
                onChange={(e) =>
                  setContactForm((prev) => ({ ...prev, instagram: e.target.value }))
                }
                placeholder="Instagram"
                className="px-4 py-3 border border-gray-300 rounded-lg"
              />
            </div>
            <div className="mt-3 space-y-3">
              <select
                value={contactForm.preferredChannel}
                onChange={(e) =>
                  setContactForm((prev) => ({
                    ...prev,
                    preferredChannel: e.target.value,
                  }))
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-lg"
              >
                <option>In-app chat</option>
                <option>Phone</option>
                <option>WhatsApp</option>
                <option>Email</option>
              </select>
              <input
                value={contactForm.note}
                onChange={(e) => setContactForm((prev) => ({ ...prev, note: e.target.value }))}
                placeholder="Public note for trainees and players"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg"
              />
              <button onClick={saveContactProfile} className="btn-primary">
                Save Contact Profile
              </button>
            </div>
          </section>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-10">
          <Link href="/coaches/create-tournament" className="card text-center hover:shadow-lg">
            <h3 className="text-xl font-bold">Create Tournament</h3>
            <p className="text-gray-600">Publish upcoming events</p>
          </Link>
          <Link href="/coaches/earnings" className="card text-center hover:shadow-lg">
            <h3 className="text-xl font-bold">Earnings</h3>
            <p className="text-gray-600">Track session and tournament revenue</p>
          </Link>
          <Link href="/messages" className="card text-center hover:shadow-lg">
            <h3 className="text-xl font-bold">Messages</h3>
            <p className="text-gray-600">Chat directly with trainees and players</p>
          </Link>
        </div>

        <section className="card mb-8">
          <h2 className="text-2xl font-bold mb-4 text-gray-900">Upcoming Sessions</h2>
          {sessions.length === 0 ? (
            <p className="text-gray-600">No sessions yet.</p>
          ) : (
            <div className="space-y-3">
              {sessions.map((session) => (
                <div
                  key={session.id}
                  className="border border-gray-200 rounded-lg p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3"
                >
                  <div>
                    <p className="font-semibold text-gray-900">{session.playerName}</p>
                    <p className="text-sm text-gray-600">
                      {session.date} at {session.time}
                    </p>
                    <p className="text-sm text-gray-600">{session.type}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <p className="font-bold text-emerald-700">KES {session.amount.toLocaleString()}</p>
                    <Link
                      href={`/messages?userId=${session.playerId}`}
                      className="px-4 py-2 border border-sky-600 text-sky-700 rounded-lg hover:bg-sky-50"
                    >
                      Message
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="card">
          <h2 className="text-2xl font-bold mb-4 text-gray-900">Your Tournaments</h2>
          {tournaments.length === 0 ? (
            <p className="text-gray-600">No tournaments created yet.</p>
          ) : (
            <div className="space-y-3">
              {tournaments.map((tournament) => (
                <div key={tournament.id} className="border border-gray-200 rounded-lg p-4">
                  <p className="font-semibold text-gray-900">{tournament.name}</p>
                  <p className="text-sm text-gray-600">
                    {tournament.date} | {tournament.location}
                  </p>
                  <p className="text-sm text-gray-600">
                    Participants: {tournament.participants} | Entry Fee: KES{" "}
                    {tournament.entryFee.toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
