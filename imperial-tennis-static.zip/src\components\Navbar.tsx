"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useAuth } from "@/components/AuthContext";
import { useRouter } from "next/navigation";
import { MessageCircle } from "lucide-react";
import { messagesService } from "@/lib/messagesService";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const { user, logout, isAuthenticated } = useAuth();
  const router = useRouter();

  const dashboardHref =
    user?.role === "coach" ? "/coaches/dashboard" : "/players/dashboard";

  const handleLogout = () => {
    logout();
    router.push("/");
  };

  useEffect(() => {
    if (!user) {
      setUnreadCount(0);
      return;
    }

    const refreshUnread = () => {
      setUnreadCount(messagesService.getUnreadCount(user.id));
    };

    refreshUnread();
    const interval = setInterval(refreshUnread, 1500);
    return () => clearInterval(interval);
  }, [user]);

  return (
    <nav className="sticky top-0 z-50 border-b border-sky-100 bg-white/95 backdrop-blur">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="text-xl font-black tracking-tight text-sky-800">
          IMPERIAL TENNIS
        </Link>

        <div className="hidden md:flex items-center gap-6">
          <Link href="/" className="text-slate-700 hover:text-sky-700 font-semibold">
            Home
          </Link>
          <Link href="/features" className="text-slate-700 hover:text-sky-700 font-semibold">
            Features
          </Link>
          {isAuthenticated && (
            <Link
              href={dashboardHref}
              className="text-slate-700 hover:text-sky-700 font-semibold"
            >
              Dashboard
            </Link>
          )}
          {isAuthenticated && (
            <Link
              href="/messages"
              className="relative text-slate-700 hover:text-sky-700 font-semibold inline-flex items-center gap-2"
            >
              <MessageCircle size={18} />
              <span>Messages</span>
              {unreadCount > 0 && (
                <span className="absolute -top-2 -right-3 min-w-5 h-5 px-1 rounded-full bg-red-500 text-white text-[11px] font-bold flex items-center justify-center">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </Link>
          )}
        </div>

        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated ? (
            <>
              <span className="text-sm text-slate-600">
                {user?.name} ({user?.role})
              </span>
              <button
                onClick={handleLogout}
                className="px-4 py-2 rounded-lg border border-emerald-600 text-emerald-700 font-semibold hover:bg-emerald-50"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                href="/auth/login"
                className="px-4 py-2 rounded-lg border border-sky-600 text-sky-700 font-semibold hover:bg-sky-50"
              >
                Sign In
              </Link>
              <Link
                href="/auth/register"
                className="px-4 py-2 rounded-lg text-white font-semibold bg-gradient-to-r from-sky-600 to-emerald-600 hover:from-sky-700 hover:to-emerald-700"
              >
                Get Started
              </Link>
            </>
          )}
        </div>

        <button className="md:hidden text-slate-700" onClick={() => setIsOpen(!isOpen)}>
          Menu
        </button>
      </div>

      {isOpen && (
        <div className="md:hidden px-6 pb-4 space-y-3 border-t border-slate-100 bg-white">
          <Link href="/" className="block text-slate-700 font-semibold">
            Home
          </Link>
          <Link href="/features" className="block text-slate-700 font-semibold">
            Features
          </Link>
          {isAuthenticated && (
            <Link href={dashboardHref} className="block text-slate-700 font-semibold">
              Dashboard
            </Link>
          )}
          {isAuthenticated && (
            <Link href="/messages" className="block text-slate-700 font-semibold">
              Messages {unreadCount > 0 ? `(${unreadCount})` : ""}
            </Link>
          )}
          {!isAuthenticated ? (
            <>
              <Link href="/auth/login" className="block text-sky-700 font-semibold">
                Sign In
              </Link>
              <Link href="/auth/register" className="block text-emerald-700 font-semibold">
                Get Started
              </Link>
            </>
          ) : (
            <button onClick={handleLogout} className="block text-emerald-700 font-semibold">
              Logout
            </button>
          )}
        </div>
      )}
    </nav>
  );
}
